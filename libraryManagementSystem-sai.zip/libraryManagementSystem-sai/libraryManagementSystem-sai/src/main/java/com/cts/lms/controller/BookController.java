package com.cts.lms.controller;

import com.cts.lms.dto.BookRequestDTO;
import com.cts.lms.dto.BookResponseDTO;
import com.cts.lms.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
@CrossOrigin
public class BookController {

    private final BookService bookService;

    @GetMapping("/view-all")
    public ResponseEntity<List<BookResponseDTO>> getAllBooks() {
        List<BookResponseDTO> books = bookService.getAllBooks();
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @GetMapping("/view/{bookId}")
    public ResponseEntity<BookResponseDTO> getBookById(@PathVariable Long bookId) {
        BookResponseDTO book = bookService.getBookById(bookId);
        return new ResponseEntity<>(book, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<BookResponseDTO> addBook(@RequestBody BookRequestDTO bookRequestDTO) {
        BookResponseDTO created = bookService.addBook(bookRequestDTO);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PatchMapping("/update/{bookId}")
    public ResponseEntity<BookResponseDTO> modifyBook(@PathVariable Long bookId,
                                                      @RequestBody BookRequestDTO bookRequestDTO) {
        BookResponseDTO updated = bookService.modifyBook(bookId, bookRequestDTO);
        return new ResponseEntity<>(updated, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{bookId}")
    public ResponseEntity<String> deleteBook(@PathVariable Long bookId) {
        String result = bookService.deleteBook(bookId);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @GetMapping("/search/author/{author}")
    public ResponseEntity<List<BookResponseDTO>> searchBooksByAuthor(@PathVariable String author) {
        List<BookResponseDTO> books = bookService.searchBooksByAuthor(author);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @GetMapping("/search/title/{title}")
    public ResponseEntity<List<BookResponseDTO>> searchBooksByTitle(@PathVariable String title) {
        List<BookResponseDTO> books = bookService.searchBooksByTitle(title);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @GetMapping("/search/genre/{genre}")
    public ResponseEntity<List<BookResponseDTO>> searchBooksByGenre(@PathVariable String genre) {
        List<BookResponseDTO> books = bookService.searchBooksByGenre(genre);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
}
