package com.cts.lms.service;

import com.cts.lms.entity.Book;
import com.cts.lms.exception.ResourceNotFoundException;
import com.cts.lms.repository.BookRepository;
import com.cts.lms.utils.IsbnFormatter;
import com.cts.lms.utils.ResetBookId;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@Transactional
public class BookService {

    private final BookRepository bookRepository;
    private final ResetBookId resetBookId;

    public BookService(BookRepository bookRepository, ResetBookId resetBookId){
        this.bookRepository = bookRepository;
        this.resetBookId = resetBookId;
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Book addBook(Book book) {
        if(bookRepository.findByIsbn(book.getIsbn()).isPresent()){
            throw new IllegalArgumentException("Book with this ISBN already exists");
        }
        List<Book> existingBook = bookRepository.findByTitleContainingIgnoreCase(book.getTitle());
        for(Book foundBook: existingBook){
            if(foundBook.getAuthor().equalsIgnoreCase(book.getAuthor())){
                foundBook.setAvailableCopies(foundBook.getAvailableCopies()+book.getAvailableCopies());
                return bookRepository.save(foundBook);
            }
        }
        return bookRepository.save(book);
    }

    public Book updateBook(Long bookId, Book bookDetails) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Book ID "+ bookId + " does not exist"));
        book.setTitle(bookDetails.getTitle());
        book.setAuthor(bookDetails.getAuthor());
        book.setGenre(bookDetails.getGenre());
        book.setIsbn(IsbnFormatter.formatIsbn(bookDetails.getIsbn()));
        book.setYearPublished(bookDetails.getYearPublished());
        book.setAvailableCopies(bookDetails.getAvailableCopies());
        return bookRepository.saveAndFlush(book);
    }

    public void deleteBook(Long bookId) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(()-> new ResourceNotFoundException("Book ID "+ bookId + " not found"));
        bookRepository.delete(book);
        if(bookRepository.count()==0){
            resetBookId.resetAutoIncrement();
        }
    }

    public Book getBookById(Long bookId) {
        return bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Book ID: "+ bookId +" - not found"));
    }

    public List<Book> searchBooksByAuthor(String author){
        List<Book> books=bookRepository.findByAuthorContainingIgnoreCase(author);
        if(books.isEmpty()){
            throw new ResourceNotFoundException("Author: "  + author + " - not found");
        }
        return books;
    }

    public List<Book> searchBooksByTitle(String title){
        List<Book> books = bookRepository.findByTitleContainingIgnoreCase(title);
        if(books.isEmpty()){
            throw new ResourceNotFoundException("Book: "+ title + " - not found");
        }
        return books;
    }

    public List<Book> searchBooksByGenre(String genre){
        List<Book> books = bookRepository.findByGenreContainingIgnoreCase(genre);
        if(books.isEmpty()){
            throw new ResourceNotFoundException("Genre: " + genre + " - not found");
        }
        return books;
    }
}