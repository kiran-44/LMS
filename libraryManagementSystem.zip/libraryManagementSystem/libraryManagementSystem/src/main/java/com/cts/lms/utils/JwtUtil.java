package com.cts.lms.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.util.Base64;
import java.util.Date;
import java.util.Random;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.SecretKey;

@Component
public class JwtUtil {

    private String secretKey;

    @PostConstruct
    public void init() {
        // Generate a random 256-bit (32-byte) secret key on startup
        byte[] randomBytes = new byte[32];
        new Random().nextBytes(randomBytes);
        this.secretKey = Base64.getEncoder().encodeToString(randomBytes);
        // System.out.println("Generated Secret Key: " + secretKey);  // Log for debugging
    }

    public String generateToken(org.springframework.security.core.userdetails.UserDetails userDetails) {
        SecretKey key = new SecretKeySpec(Base64.getDecoder().decode(secretKey), SignatureAlgorithm.HS256.getJcaName());
        return Jwts.builder()
                .setSubject(userDetails.getUsername())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10)) // Token valid for 10 hours
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    public boolean validateToken(String token, org.springframework.security.core.userdetails.UserDetails userDetails) {
        return extractUsername(token).equals(userDetails.getUsername()) && !isTokenExpired(token);
    }

    public String extractUsername(String token) {
        return extractClaims(token).getSubject();
    }

    private boolean isTokenExpired(String token) {
        return extractClaims(token).getExpiration().before(new Date());
    }

    private Claims extractClaims(String token) {
        SecretKey key = new SecretKeySpec(Base64.getDecoder().decode(secretKey), SignatureAlgorithm.HS256.getJcaName());
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }
}
