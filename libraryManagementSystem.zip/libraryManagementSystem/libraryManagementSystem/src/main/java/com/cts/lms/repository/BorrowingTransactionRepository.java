package com.cts.lms.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.lms.entity.BorrowingTransaction;


public interface BorrowingTransactionRepository extends JpaRepository<BorrowingTransaction, Long> {

    Optional<BorrowingTransaction> findByMemberIdAndBookIdAndStatus(String memberId, Long bookId, String status);
    @Query("SELECT bt FROM BorrowingTransaction bt WHERE bt.status = 'Borrowed' AND bt.borrowDate < :overdueDate")
    List<BorrowingTransaction> findOverdueTransactions(LocalDate minusDays);
}



