package com.cts.lms.controller;

import com.cts.lms.dto.AuthRequest;
import com.cts.lms.service.CustomUserDetailsService;
import com.cts.lms.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public String login(@RequestBody AuthRequest request) throws Exception {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
        } catch (Exception e) {
            throw new Exception("Invalid username or password");
        }

        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getPassword());
        return jwtUtil.generateToken(userDetails);
    }

    @GetMapping("/test")
    public String testEndpoint() {
        return "JWT Security is working!";
    }
}
