package com.cts.lms.controller;

import com.cts.lms.entity.Book;
import com.cts.lms.exception.GlobalExceptionHandler;
import com.cts.lms.exception.ResourceNotFoundException;
import com.cts.lms.service.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.Year;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class BookControllerTest {

    private MockMvc mockMvc;

    @Mock
    private BookService bookService;

    @InjectMocks
    private BookController bookController;

    private Book book;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(bookController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
        book = new Book(1L, "Java Programming", "John Doe", "Technology", "1234567890",
                Year.of(2020), 5);
    }

    @Test
    void getBookById_WhenBookDoesNotExist_ShouldReturnNotFound() throws Exception {
        when(bookService.getBookById(1L)).thenThrow(new ResourceNotFoundException("Book ID: 1 not found"));

        mockMvc.perform(get("/api/books/1").accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNotFound())
                .andExpect(header().string(HttpHeaders.CONTENT_TYPE, "application/json"))
                .andExpect(jsonPath("$.message").value("Book ID: 1 not found"));
    }

    @Test
    void getAllBooks_ShouldReturnBooksList() throws Exception {
        when(bookService.getAllBooks()).thenReturn(List.of(book));
        mockMvc.perform(get("/api/books"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].title").value("Java Programming"))
                .andExpect(jsonPath("$[0].author").value("John Doe"));
    }

    @Test
    void getBookById_WhenBookExists_ShouldReturnBook() throws Exception {
        when(bookService.getBookById(1L)).thenReturn(book);
        mockMvc.perform(get("/api/books/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Java Programming"))
                .andExpect(jsonPath("$.author").value("John Doe"));
    }

    @Test
    void deleteBook_WhenBookExists_ShouldReturnNoContent() throws Exception {
        doNothing().when(bookService).deleteBook(1L);
        mockMvc.perform(delete("/api/books/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    void updateBook_ShouldReturnUpdatedBook() throws Exception {
        Book updatedBook = new Book(1L, "Advanced Java", "John Doe", "Technology", "1234567890",
                Year.of(2021), 3);

        when(bookService.updateBook(eq(1L), any(Book.class))).thenReturn(updatedBook);

        mockMvc.perform(put("/api/books/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                {
                    "title": "Advanced Java",
                    "author": "John Doe",
                    "genre": "Technology",
                    "isbn": "1234567890",
                    "yearPublished": 2021,
                    "availableCopies": 3
                }"""))
                .andDo(print()) // Debugging
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Advanced Java"))
                .andExpect(jsonPath("$.availableCopies").value(3));
    }

    @Test
    void searchBooksByTitle_ShouldReturnMatchingBooks() throws Exception {
        List<Book> books = List.of(book);
        when(bookService.searchBooksByTitle("Java")).thenReturn(books);

        mockMvc.perform(get("/api/books/search/title")
                        .param("title", "Java"))
                .andDo(print()) // Debugging
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].title").value("Java Programming"));
    }

    @Test
    void addBook_ShouldReturnCreatedBook() throws Exception {
        when(bookService.addBook(any(Book.class))).thenReturn(book);

        mockMvc.perform(post("/api/books")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                {
                    "title": "Java Programming",
                    "author": "John Doe",
                    "genre": "Technology",
                    "isbn": "1234567890",
                    "yearPublished": 2020,
                    "availableCopies": 5
                }"""))
                .andDo(print()) // Debugging
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Java Programming"))
                .andExpect(jsonPath("$.author").value("John Doe"));
    }

    @Test
    void deleteBook_WhenBookDoesNotExist_ShouldReturnNotFound() throws Exception {
        doThrow(new ResourceNotFoundException("Book ID: 1 not found"))
                .when(bookService).deleteBook(1L);

        mockMvc.perform(delete("/api/books/1"))
                .andDo(print()) // Debugging
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Book ID: 1 not found"));
    }

}
