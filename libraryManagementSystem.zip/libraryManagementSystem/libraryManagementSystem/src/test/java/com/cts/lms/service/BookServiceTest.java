package com.cts.lms.service;

import com.cts.lms.entity.Book;
import com.cts.lms.exception.ResourceNotFoundException;
import com.cts.lms.repository.BookRepository;
import com.cts.lms.utils.ResetBookId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.ArgumentMatchers;

import java.time.Year;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookServiceTest {

    @Mock
    private BookRepository bookRepository;

    @Mock
    private ResetBookId resetBookId;

    @InjectMocks
    private BookService bookService;

    private Book book;

    @BeforeEach
    void setUp() {
        book = new Book(1L, "Java Programming", "John Doe", "Technology", "1234567890",
                Year.of(2020), 5);
    }

    @Test
    void getAllBooks_ShouldReturnListOfBooks() {
        when(bookRepository.findAll()).thenReturn(List.of(book));

        List<Book> books = bookService.getAllBooks();

        assertEquals(1, books.size());
        assertEquals("Java Programming", books.get(0).getTitle());
        verify(bookRepository, times(1)).findAll();
    }

    @Test
    void getBookById_WhenBookExists_ShouldReturnBook() {
        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));
        Book foundBook = bookService.getBookById(1L);
        assertNotNull(foundBook);
        assertEquals("Java Programming", foundBook.getTitle());
        verify(bookRepository, times(1)).findById(1L);
    }

    @Test
    void getBookById_WhenBookDoesNotExist_ShouldThrowException() {
        when(bookRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> bookService.getBookById(1L));
    }

    @Test
    void addBook_WhenIsbnIsUnique_ShouldSaveBook() {
        when(bookRepository.findByIsbn(ArgumentMatchers.anyString())).thenReturn(Optional.empty());
        when(bookRepository.save(any(Book.class))).thenReturn(book);
        Book savedBook = bookService.addBook(book);
        assertNotNull(savedBook);
        assertEquals("Java Programming", savedBook.getTitle());
        verify(bookRepository, times(1)).save(any(Book.class));
    }

    @Test
    void addBook_WhenIsbnExists_ShouldThrowException() {
        when(bookRepository.findByIsbn(ArgumentMatchers.anyString())).thenReturn(Optional.of(book));
        Exception exception = assertThrows(IllegalArgumentException.class, () -> bookService.addBook(book));
        assertEquals("Book with this ISBN already exists", exception.getMessage());
        verify(bookRepository, times(1)).findByIsbn(ArgumentMatchers.anyString());
        verify(bookRepository, never()).save(any(Book.class));
    }

    @Test
    void deleteBook_WhenNoBooksLeft_ShouldResetAutoIncrement() {
        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));
        when(bookRepository.count()).thenReturn(0L);
        bookService.deleteBook(1L);
        verify(bookRepository, times(1)).delete(book);
        verify(resetBookId, times(1)).resetAutoIncrement();
    }

    @Test
    void searchBooksByAuthor_ShouldReturnMatchingBooks() {
        when(bookRepository.findByAuthorContainingIgnoreCase("John Doe")).thenReturn(List.of(book));

        List<Book> books = bookService.searchBooksByAuthor("John Doe");

        assertEquals(1, books.size());
        assertEquals("Java Programming", books.get(0).getTitle());
        verify(bookRepository, times(1)).findByAuthorContainingIgnoreCase("John Doe");
    }
}
